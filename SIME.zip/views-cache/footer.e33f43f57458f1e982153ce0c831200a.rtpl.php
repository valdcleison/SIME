<?php if(!class_exists('Rain\Tpl')){exit;}?>    <footer class="site-footer">
      <div class="text-center">
        <p>
          &copy; Copyrights <strong>SIME</strong>. All Rights Reserved
        </p>
        <div class="credits">
          
          Created with Dashio template by <a href="https://templatemag.com/">TemplateMag</a>
        </div>
        <a href="blank.html#" class="go-top">
          <i class="fa fa-angle-up"></i>
          </a>
      </div>
    </footer>

  </section>

  <script src="/res/Admin/lib/jquery/jquery.min.js"></script>
  <script src="/res/Admin/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="/res/Admin/lib/jquery-ui-1.9.2.custom.min.js"></script>
  <script src="/res/Admin/lib/jquery.ui.touch-punch.min.js"></script>
  <script class="include" type="text/javascript" src="/res/Admin/lib/jquery.dcjqaccordion.2.7.js"></script>
  <script src="/res/Admin/lib/jquery.scrollTo.min.js"></script>
  <script src="/res/Admin/lib/jquery.nicescroll.js" type="text/javascript"></script>

  <script src="/res/Admin/lib/common-scripts.js"></script>
  
</body>

</html>
