<?php if(!class_exists('Rain\Tpl')){exit;}?>


    <!-- Footer -->
    <footer class="py-5 bg-black">
      <div class="container">
        <p class="m-0 text-center text-white small">Copyright &copy; Your Website 2018</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="/res/Layout/vendor/jquery/jquery.js"></script>
    <script src="/res/Layout/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="/res/Layout/js/js.js"></script>


  </body>

</html>
