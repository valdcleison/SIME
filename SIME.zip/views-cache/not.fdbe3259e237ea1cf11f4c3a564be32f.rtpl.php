<?php if(!class_exists('Rain\Tpl')){exit;}?><!DOCTYPE html>
<html>
<head>
	<title>asdja</title>
</head>
<body>
asdjko
</body>
</html>